package com.table;

public class Test {
	public String title;
	public String name;
	public String category;
	public int score;
}
