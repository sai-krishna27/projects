package com.table;

public class User {
	public String name;
	
	public String email;
	
	public String password;
	
}
