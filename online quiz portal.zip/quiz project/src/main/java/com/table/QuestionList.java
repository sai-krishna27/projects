package com.table;

public class QuestionList {
	public int id;
	public String question;
	public String op1;
	public String op2;
	public String op3;
	public String op4;
	public String correct;
}
