package com.table;

public class QuizList {
	public int id;
	public String title;
	public String category;
}
